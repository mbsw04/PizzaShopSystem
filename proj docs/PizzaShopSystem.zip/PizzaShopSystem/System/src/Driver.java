class resource {

    static userHandler uh = new userHandler();
    static Inventory inventory = new Inventory();
    static User currentUser;

    public static void main(String[] args) {
        EnterPage test = new EnterPage(null);

    }

}
